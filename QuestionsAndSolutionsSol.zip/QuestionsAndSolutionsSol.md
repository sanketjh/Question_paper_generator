--- 
 title: Solutions 
---

1. $(x+2)(x+3)=0$

$\implies x=-2$ or $x=-3$ 

2. Solution Not Available 

3. $a^2+2ab+b^2$ 

4. Solution Not Available 

5. $a^2-2ab+b^2$ 

6. $(a+b)(a-b)$ 
