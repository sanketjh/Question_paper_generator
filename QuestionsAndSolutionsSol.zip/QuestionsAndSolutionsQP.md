--- 
 title: Question Paper (Maximum Marks - 12.0) 
 author: Roll No.- 
 date: December 30, 2020 
--- 
 
# Questions 
<!--- Questions begin below. Do NOT edit the content below. To change the question content, please edit the table directly. To change the position of Maximum Marks, use only this expression: 'Maximum Marks -' -->

1. Solve for $x$: $x^2+5x+6=0$ 
<div style="text-align: right;"> [2.0] </div>

2. Let  $h[n] = (0.3)^nu[n]$. Find the value of
\begin{equation*}
\sum_{n=0}^\infty |h[n]|^2
\end{equation*} 
<div style="text-align: right;"> [2.0] </div>

3. What is the expansion of $(a+b)^2$? 
<div style="text-align: right;"> [2.0] </div>

4. Find the roots of $f(x) = 3 x^2 + 9 x + 3$. 
<div style="text-align: right;"> [2.0] </div>

5. What is the expansion of $(a-b)^2$? 
<div style="text-align: right;"> [2.0] </div>

6. Factorise: $a^2-b^2$ 
<div style="text-align: right;"> [2.0] </div>
