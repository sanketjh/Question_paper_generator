--- 
 title: Solutions 
---

1. $(x+2)(x+3)=0$

$\implies x=-2$ or $x=-3$ 

2. $a^2+2ab+b^2$ 

3. Solution Not Available 

4. $a^2-2ab+b^2$ 

5. $(a+b)(a-b)$ 

6. Solution Not Available 
